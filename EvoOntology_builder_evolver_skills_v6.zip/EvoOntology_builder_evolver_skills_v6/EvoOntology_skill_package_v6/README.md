# EvoOntology Builder and Evolver Skills

This package keeps the original skills largely intact while reorganizing their workflows to match the method presentation in the paper.

- Builder: the original six steps are grouped into **Workload-Guided Probing** and **Evidence-Grounded Commitment**.
- Evolver: initialization remains outside the loop, while the original diagnosis, attribution, intervention, verification, evaluation, and update stages are grouped into the four-step loop **Diagnose → Attribute → Patch → Evaluate/Gate**.

The semantic schema and interaction protocol are adapted from the supplied project files. The data-boundary reference briefly states the reciprocal two-fold protocol, the 70/30 construction-validation split, and the separation from held-out evaluation.


## Schema alignment

The schema keeps the original five serialized record types (`Term`, `Mapping`, `Relation`, `Constraint`, and `Evidence`) while clarifying the graph view used in the paper: four node families and two edge families. `Relation` records represent Semantic Relation edges, and object references induce Structural References.


## Reference scope

To keep the skills general and avoid imposing unnecessary artifact or logging requirements, both skills use three shared references:

- `semantic-schema.md`
- `semantic-interaction-protocol.md`
- `semantic-layer-data-boundary.md`

The Evolver additionally includes a short `exploration-guide.md` for cases where progress stagnates or similar patches repeat. It provides general search directions without defining any mandatory logging or artifact format. Evolution records, memory, and research-integrity guidance remain expressed briefly inside the Evolver skill.
